/*import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());

app.get('/api/rag-search', (req, res) => {
  const topic = req.query.topic as string;
  // Example: generate random dental office and steps
  const steps = [
    {
      question: `How to schedule a ${topic}?`,
      answer: `Call "Happy Smiles Dental Office" at 555-1234`,
      instructions: [
        'Step 1: Call the dental office.',
        'Step 2: Ask for root canal appointment availability.',
        'Step 3: Confirm date and time.',
        'Step 4: Enter the appointment in your calendar.'
      ]
    }
  ];
  res.json(steps);
});

app.listen(4000, () => {
  console.log('RAG mock server running on http://localhost:4000');
});


*/ 

import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json()); // Enable JSON body parsing if needed

app.get('/api/rag-search', (req, res) => {
  // Plain JS version of TypeScript 'as string'
  const topic = String(req.query.topic);

  // Example: generate random dental office and steps
  const steps = [
    {
      question: `How to schedule a ${topic}?`,
      answer: `Call "Happy Smiles Dental Office" at 555-1234`,
      instructions: [
        'Step 1: Call the dental office.',
        'Step 2: Ask for root canal appointment availability.',
        'Step 3: Confirm date and time.',
        'Step 4: Enter the appointment in your calendar.'
      ]
    }
  ];

  res.json(steps);
});

app.listen(4000, () => {
  console.log('RAG mock server running on http://localhost:4000');
});
