rag.ts

(RAG Search Integration)

import type { Step } from './types';

export async function fetchRAGSteps(topic: string): Promise<Step[]> {
  try {
    const response = await fetch(`/api/rag-search?topic=${encodeURIComponent(topic)}`);
    if (!response.ok) throw new Error('RAG search failed');
    const data: Step[] = await response.json();
    return data;
  } catch (error) {
    console.error(error);
    // Fallback to mock data
    return [
      {
        question: `How to schedule a ${topic}?`,
        answer: 'Mock answer from RAG search.',
        instructions: ['Step 1: Call the office', 'Step 2: Confirm date and time']
      }
    ];
  }
}
