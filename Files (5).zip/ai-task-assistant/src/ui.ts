
import type { Step, TaskState } from './types';

const textElement = document.getElementById('text') as HTMLDivElement;
const instructionsElement = document.getElementById('instructions') as HTMLUListElement;
const aiButton = document.getElementById('ai-button') as HTMLButtonElement;
const userButton = document.getElementById('user-button') as HTMLButtonElement;

export function renderStep(step: Step, state: TaskState) {
  textElement.innerText = step.question;
  instructionsElement.innerHTML = '';
  step.instructions?.forEach(inst => {
    const li = document.createElement('li');
    li.textContent = inst;
    instructionsElement.appendChild(li);
  });

  aiButton.disabled = false;
  userButton.disabled = false;
}

export function updateProgress(state: TaskState) {
  console.log(`Completed steps: ${state.completedSteps.length}/${state.steps.length}`);
}
