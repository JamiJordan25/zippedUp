data-model.ts

// Interfaces for each step of a task
export interface TaskStep {
  question: string;
  answer: string;
  instructions: string[];
}

// Interface for the whole task
export interface Task {
  topic: string;
  steps: TaskStep[];
  currentStep: number;
}

// Helper to create a new task
export const createTask = (topic: string, steps: TaskStep[]): Task => ({
  topic,
  steps,
  currentStep: 0
});
