app.ts:

import { fetchRAGSteps } from './rag';
import { executeAITask } from './ai';
import { renderStep, updateProgress } from './ui';
import type { TaskState, Step } from './types';

let state: TaskState = {
  currentStep: 0,
  steps: [],
  completedSteps: []
};

async function startTopic(topic: string) {
  state.steps = await fetchRAGSteps(topic);
  state.currentStep = 0;
  state.completedSteps = [];
  renderCurrentStep();
}

function renderCurrentStep() {
  const step = state.steps[state.currentStep];
  if (!step) return console.log('No more steps.');
  renderStep(step, state);
}

// Event listeners
document.getElementById('ai-button')?.addEventListener('click', async () => {
  const step = state.steps[state.currentStep];
  if (!step) return;
  await executeAITask(step);
  state.completedSteps.push(state.currentStep);
  nextStep();
});

document.getElementById('user-button')?.addEventListener('click', () => {
  state.completedSteps.push(state.currentStep);
  nextStep();
});

function nextStep() {
  state.currentStep += 1;
  if (state.currentStep >= state.steps.length) {
    alert('All steps completed!');
  } else {
    renderCurrentStep();
    updateProgress(state);
  }
}

// Topic button example
document.getElementById('topic-dental')?.addEventListener('click', () => {
  startTopic('root canal dental appointment');
});
