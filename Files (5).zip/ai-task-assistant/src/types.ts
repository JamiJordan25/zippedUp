
(TypeScript Types)

export interface Step {
  question: string;
  answer: string;
  instructions?: string[];
  nextStep?: number;
}

export interface TaskState {
  currentStep: number;
  steps: Step[];
  completedSteps: number[];
}
